-- Add authorization tracking fields to users table
-- Run this migration in phpMyAdmin

USE votesecure_db;

-- Add authorized_at timestamp
ALTER TABLE users 
ADD COLUMN IF NOT EXISTS authorized_at TIMESTAMP NULL DEFAULT NULL AFTER authorized;

-- Add authorized_by (references admin user_id)
ALTER TABLE users 
ADD COLUMN IF NOT EXISTS authorized_by INT NULL DEFAULT NULL AFTER authorized_at,
ADD INDEX idx_authorized_by (authorized_by);

-- Add foreign key constraint if authorized_by column exists
-- Note: This will fail if the referenced admin doesn't exist yet, so it's commented
-- ALTER TABLE users 
-- ADD CONSTRAINT fk_authorized_by FOREIGN KEY (authorized_by) REFERENCES users(id) ON DELETE SET NULL;

-- Update existing authorized users to have authorized_at timestamp
UPDATE users 
SET authorized_at = created_at 
WHERE authorized = 1 AND authorized_at IS NULL;

