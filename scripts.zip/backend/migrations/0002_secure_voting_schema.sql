-- Secure Voting System Schema Updates
-- This migration adds all necessary fields for the secure voting system

USE votesecure_db;

-- Add new columns to users table
ALTER TABLE users 
ADD COLUMN IF NOT EXISTS date_of_birth DATE NULL AFTER name,
ADD COLUMN IF NOT EXISTS phone_number VARCHAR(20) NULL AFTER email,
ADD COLUMN IF NOT EXISTS voter_id VARCHAR(50) NULL UNIQUE AFTER phone_number,
ADD COLUMN IF NOT EXISTS temp_password VARCHAR(255) NULL AFTER password,
ADD COLUMN IF NOT EXISTS password_changed TINYINT(1) NOT NULL DEFAULT 0 AFTER temp_password,
ADD COLUMN IF NOT EXISTS has_voted TINYINT(1) NOT NULL DEFAULT 0 AFTER password_changed,
ADD COLUMN IF NOT EXISTS blockchain_address VARCHAR(255) NULL AFTER has_voted,
ADD COLUMN IF NOT EXISTS otp VARCHAR(10) NULL AFTER blockchain_address,
ADD COLUMN IF NOT EXISTS otp_expiry DATETIME NULL AFTER otp,
ADD COLUMN IF NOT EXISTS face_verified TINYINT(1) NOT NULL DEFAULT 0 AFTER face_image,
ADD COLUMN IF NOT EXISTS last_login DATETIME NULL AFTER otp_expiry,
ADD COLUMN IF NOT EXISTS login_attempts TINYINT UNSIGNED NOT NULL DEFAULT 0 AFTER last_login,
ADD COLUMN IF NOT EXISTS account_locked_until DATETIME NULL AFTER login_attempts;

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_voter_id ON users(voter_id);
CREATE INDEX IF NOT EXISTS idx_has_voted ON users(has_voted);
CREATE INDEX IF NOT EXISTS idx_face_verified ON users(face_verified);

-- Create blockchain_votes table to store votes on the blockchain
CREATE TABLE IF NOT EXISTS blockchain_votes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    election_id INT NOT NULL,
    candidate_id INT NOT NULL,
    transaction_hash VARCHAR(255) NOT NULL,
    block_number BIGINT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_election (user_id, election_id),
    INDEX idx_transaction (transaction_hash)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create voter_activity_log table for audit trail
CREATE TABLE IF NOT EXISTS voter_activity_log (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    activity_type ENUM('login', 'face_verification', 'otp_sent', 'otp_verified', 'password_changed', 'vote_cast') NOT NULL,
    ip_address VARCHAR(45) NOT NULL,
    user_agent TEXT,
    status ENUM('success', 'failed') NOT NULL,
    details TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_activity (user_id, activity_type, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
