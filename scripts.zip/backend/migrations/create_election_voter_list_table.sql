-- Migration: Create election_voter_list table
-- This table stores the voter list uploaded for each election
-- Each row represents a voter eligible for a specific election

CREATE TABLE IF NOT EXISTS `election_voter_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `election_id` int(11) NOT NULL,
  `voter_id` varchar(50) NOT NULL,
  `email` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_election_voter` (`election_id`, `voter_id`),
  UNIQUE KEY `unique_election_email` (`election_id`, `email`),
  KEY `election_id` (`election_id`),
  KEY `email` (`email`),
  KEY `voter_id` (`voter_id`),
  CONSTRAINT `election_voter_list_ibfk_1` FOREIGN KEY (`election_id`) REFERENCES `elections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Index for fast email lookup across all elections
CREATE INDEX `idx_email_lookup` ON `election_voter_list` (`email`);

