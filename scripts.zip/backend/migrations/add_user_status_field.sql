-- Add user status field to track TEMP_PASSWORD vs ACTIVE status
-- Run this migration to add status tracking for voter accounts

USE votesecure_db;

-- Add status column if it doesn't exist
ALTER TABLE users 
ADD COLUMN IF NOT EXISTS account_status ENUM('TEMP_PASSWORD', 'ACTIVE', 'LOCKED', 'SUSPENDED') 
DEFAULT 'TEMP_PASSWORD' 
AFTER password_changed;

-- Update existing voters with temp_password to TEMP_PASSWORD status
UPDATE users 
SET account_status = 'TEMP_PASSWORD' 
WHERE role = 'voter' 
  AND (temp_password IS NOT NULL AND temp_password != '')
  AND (password_changed IS NULL OR password_changed = 0);

-- Update existing voters who changed password to ACTIVE status
UPDATE users 
SET account_status = 'ACTIVE' 
WHERE role = 'voter' 
  AND password_changed = 1 
  AND (temp_password IS NULL OR temp_password = '');

-- Create index for faster lookups
CREATE INDEX IF NOT EXISTS idx_account_status ON users(account_status);

